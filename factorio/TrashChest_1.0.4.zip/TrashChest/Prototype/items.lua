data:extend{
    {
        type = "item",
        name = "trashcan",
        icon = "__TrashChest__/Graphics/trashcan.png",
        tint = { a = 255, r = 255, g = 255, b = 255},
        icon_size = 32,
        place_result = "trashcan",
        subgroup = "storage",
        stack_size = 50
    }
}