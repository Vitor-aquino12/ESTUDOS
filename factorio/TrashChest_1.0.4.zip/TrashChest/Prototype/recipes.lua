data:extend {
    {
        type = "recipe",
        name = "trashcan",
        enabled = false,
        ingredients =
        {
          {type = "item", name = "iron-plate", amount = 100},
          {type = "item", name = "electronic-circuit", amount = 25}
        },
        energy_required = 15,
        results = {{type = "item", name = "trashcan", amount = 1}},
    }
}