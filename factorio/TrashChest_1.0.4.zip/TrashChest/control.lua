script.on_event(defines.events.on_built_entity, function(event)
  if event.entity.name == "trashcan" then
    event.entity.remove_unfiltered_items = true
  end
end)

script.on_event(defines.events.on_robot_built_entity, function(event)
  if event.entity.name == "trashcan" then
    event.entity.remove_unfiltered_items = true
  end
end)

