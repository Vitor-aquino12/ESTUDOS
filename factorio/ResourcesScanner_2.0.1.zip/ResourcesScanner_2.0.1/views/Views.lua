require("views.MapOptionsView")
require("views.ResourcesView")